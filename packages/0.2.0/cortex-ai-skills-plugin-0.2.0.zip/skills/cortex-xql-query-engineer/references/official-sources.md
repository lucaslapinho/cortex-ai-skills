# Official Source Register

Current scoped update: [2026-11-13 refresh](2026-11-13-refresh.md). Historical entries below retain their original dates and applicability.

This is the standalone source register for `cortex-xql-query-engineer`. It records the first-party material used by the Skill without requiring repository-level research files.

**Review date:** 2026-09-04  
**Review rule:** product behavior is time-sensitive. Re-open the specific page for the target product/version before a production decision. A successful link check does not prove tenant availability or execution.

## Focused refresh — 2026-10-23

Read the [dated semantic refresh](2026-10-23-refresh.md) for newly inspected language, BIOC/correlation and API claims. The `regextract`, `dedup` and real-time-action discrepancies remain; API origin/counting ambiguities are now explicitly retained. This supplements the historical register rather than redating every entry. `D: PASS` is claim-scoped; new-runtime `S/C/E: NOT RUN`.

## Targeted Astra semantic recheck — 2026-09-06

This is a claim-level refresh, not a blanket redating of the original register. The following official pages were reopened and their relevant content inspected; no tenant was accessed.

| Source | Claim actually rechecked and boundary |
|---|---|
| [dedup](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/dedup.md) | Optional retention control and separate final order confirmed. Normative numeric/string keys conflict with a boolean-key example; follow the normative restriction and retain boolean acceptance as UNVERIFIED. Equal-value tie policy is unspecified, not a deterministic full-row guarantee. |
| [join](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/join.md), [last](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/functions/last.md) | Join defaults, field-conflict versus join-type distinction and lost ordering; chronological aggregate selection and last-value null behavior. Neither establishes tenant results. |
| [General regextract](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/functions/regextract.md), [XDR 3.x regextract](https://cortex-docs.paloaltonetworks.com/cortex-xdr-3.x/cortex-xdr-3.x-documentation/cortex-xdr-xql/functions/regextract.md) | Scalar-string/null versus array return-shape discrepancy persists; preserve VERSION-DEPENDENT and require target evidence. |
| [target](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/target.md), [limit](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/limit.md) | Final-stage persistence and overwrite default; result defaults remain context-sensitive, not upstream work or performance guarantees. |
| [Migrated XSIAM correlation](https://cortex-docs.paloaltonetworks.com/cortex-xsiam/detect-investigate-and-respond-to-threats/threat-management/detection-rules/what-are-detection-rules/whats-a-correlation-rule/create-a-correlation-rule.md), [legacy official indexed page](https://docs-cortex.paloaltonetworks.com/r/Cortex-XSIAM/Cortex-XSIAM-3.x-Documentation/Create-a-correlation-rule?contentId=bVMQUHW0PR_zPWqYqM4sWA) | Migrated content confirms restricted real-time stages/functions, required filter, timing and safeguards, but omits the old Generate-issue-only note still present in the official search index. That indexed text is dated evidence, not proof of a current tenant. Preserve the prior action restriction as VERSION-DEPENDENT; omission is not new write support. |

`D: PASS` applies only to the bounded content observations above. Current real-time action availability remains unresolved across document variants; `C/E: NOT RUN` throughout.

## Classification policy

- `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` means the cited syntax or general behavior was in current first-party material at the review cut; tenant schema, license, configuration, access, data population, compilation, and execution remain unknown.
- `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` means the source is current but its behavior is explicitly bounded by product, release, license, deployment, or execution surface.
- `VERSION-DEPENDENT / OFFICIAL-EXAMPLE / TENANT-UNVERIFIED` means a first-party example is pinned but cannot establish current tenant schema or compatibility.

## Product, workflow, and source-selection references

| ID | Official source | Product/surface and applicability | Classification | Limitation and tenant gap |
|---|---|---|---|---|
| Q01 | [How to build XQL queries](https://docs-cortex.paloaltonetworks.com/r/Cortex-XSIAM/Cortex-XSIAM-3.x-Documentation/How-to-build-XQL-queries) | Cortex XSIAM 3.x; pipeline construction and source selection. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Documents default `xdr_data` unless tenant default changed; source/schema still tenant-specific. |
| Q02 | [Datasets and presets](https://docs-cortex.paloaltonetworks.com/r/Cortex-XSIAM/Cortex-XSIAM-3.x-Documentation/Datasets-and-presets) | Cortex XSIAM 3.x; tenant dataset/preset discovery. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Availability follows integrations/configuration; autocomplete/indexing can lag. |
| Q03 | [XQL Command Reference](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme.md) | General Cortex XQL syntax and semantics. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | A globally documented construct can still be disallowed in BIOC, correlation, XQLp, or a source context. |
| Q04 | [Stages list](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/stages-list.md) | General Cortex XQL stage inventory. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Presence in the list is not restricted-context compatibility. |
| Q05 | [XSIAM Data Model Schema](https://cortex-docs.paloaltonetworks.com/xsiam-data-model-schema/readme.md) | Cortex XSIAM/XDM fields, aliases, constants, and fieldsets. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Does not prove mapping or population in the target tenant. |
| Q06 | [XQL Query best practices](https://docs-cortex.paloaltonetworks.com/r/Cortex-XSIAM/Cortex-XSIAM-3.x-Documentation/XQL-Query-best-practices) | Cortex XSIAM 3.x; time, filtering, projection, limits, and performance guidance. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Context limits differ; guidance does not prove a measured performance gain. |
| Q07 | [Query Center permissions](https://docs-cortex.paloaltonetworks.com/r/Cortex-XSIAM/Cortex-XSIAM-3.x-Documentation/Query-Center-permissions) | Cortex XSIAM 3.x; execution authorization and visible result scope. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Effective RBAC/SBAC and identity scope must be observed. |
| Q08 | [Manage access to saved queries](https://docs-cortex.paloaltonetworks.com/r/Cortex-XSIAM/Cortex-XSIAM-3.x-Documentation/Manage-access-to-saved-queries) | Cortex XSIAM 3.x; saved-query object sharing. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Object visibility and dataset-row scope are separate. |
| Q09 | [Query case and issue data](https://docs-cortex.paloaltonetworks.com/r/Cortex-XDR/Cortex-XDR-5.x-Documentation/Query-case-and-issue-data) | Cortex XDR 5.x only; Case/Issue query sources. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Do not infer XSIAM dataset names or complete Issue/field coverage. |
| Q10 | [Create an XQL query](https://docs-cortex.paloaltonetworks.com/r/Cortex-XDR/Cortex-XDR-5.x-Documentation/Create-XQL-query?contentId=9Gvfbx_VJQzkKWUZVHy1AQ) | Cortex XDR 5.x interactive query workflow and downstream uses. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Interactive success is not rule-conversion proof. |
| Q11 | [Research a known threat — XSIAM](https://cortex-docs.paloaltonetworks.com/cortex-xsiam/detect-investigate-and-respond-to-threats/investigation-and-response/research-a-known-threat.md); [Research a known threat — XDR 5](https://cortex-docs.paloaltonetworks.com/cortex-xdr-5.x/detect-investigate-and-respond-to-threats/investigate-and-respond-to-cases/research-a-known-threat.md) | Product-specific lead-driven XQL refinement and investigation. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | UI, license, permissions, schema, and rule promotion remain product/tenant-specific. |
| Q12 | [Legacy Query Builder](https://cortex-docs.paloaltonetworks.com/cortex-xdr-5.x/reference-and-developer-docs/cortex-xdr-xql/build-xql-queries/legacy-query-builder.md) | Cortex XDR 5.x Legacy Query Builder only. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Do not project the entity sources or UI onto XSIAM/Cortex Cloud. |
| Q13 | [XQL query API](https://cortex-docs.paloaltonetworks.com/xsiam-api/cortex-platform/xql-query.md) | Cortex XSIAM Platform API 3.6 snapshot; start, ordinary result retrieval, quota, and stream retrieval. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Ordinary Get Results is capped at 1,000 and has no pagination; use the documented stream flow above 1,000. Recheck authentication, license, RBAC/SBAC, quota, response contract, concurrency, and bounded polling. |
| Q14 | [Data retention](https://docs-cortex.paloaltonetworks.com/r/Cortex-XSIAM/Cortex-XSIAM-3.x-Documentation/Data-retention) | Cortex XSIAM 3.x; search-window/retention constraints. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Retention varies by data and entitlement; no global lookback is safe. |
| Q15 | [Graph Search permissions](https://docs-cortex.paloaltonetworks.com/r/Cortex-XSIAM/Cortex-XSIAM-3.x-Documentation/Graph-Search-permissions) | Cortex XSIAM 3.x cloud graph investigation. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Graph Search is a separate licensed/permissioned surface, not proof of XQL access. |

## Language, schema, and restricted-context references

| ID | Official source | Product/surface and applicability | Classification | Limitation and tenant gap |
|---|---|---|---|---|
| Q16 | [alter](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/alter.md) | General XQL field creation/modification. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Function type and target-context support need separate checks. |
| Q17 | [comp](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/comp.md) | General XQL aggregation/grouping. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Changes cardinality and discards other fields; not supported everywhere. |
| Q18 | [dedup](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/dedup.md) | General XQL numeric/string-key deduplication. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Omitted `by` gives arbitrary retention; expensive at scale. |
| Q19 | [join](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/join.md) | General XQL query combination. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Types, key multiplicity, conflicts, and target-context support require validation. |
| Q20 | [fields](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/fields.md) | General XQL projection/aliasing. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Functions/creation are disallowed; retained/aliased schema controls downstream stages. |
| Q21 | [filter](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/filter.md) | General XQL boolean filtering, null, string/regex, set, CIDR, and subquery forms. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Types, parentheses, and source/context compatibility still matter. |
| Q22 | [XSIAM supported operators](https://cortex-docs.paloaltonetworks.com/cortex-xsiam/reference-and-developer-docs/cortex-agentix-xql/get-started-with-xql/supported-operators.md); [XDR 5 supported operators](https://cortex-docs.paloaltonetworks.com/cortex-xdr-5.x/reference-and-developer-docs/cortex-xdr-xql/get-started-with-xql/supported-operators.md) | Product-specific comparison/set/string/regex/CIDR operators. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Apply only the target product reference; do not universalize regex behavior. |
| Q23a | [Current general `regextract()`](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/functions/regextract.md) | Current general XQL; scalar first-capture-group string or null. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Conflicts with Q23b; require target/version/compiler proof before downstream typing. |
| Q23b | [Cortex XDR 3.x `regextract()`](https://cortex-docs.paloaltonetworks.com/cortex-xdr-3.x/cortex-xdr-3.x-documentation/cortex-xdr-xql/functions/regextract.md) | Version-scoped XDR 3.x; array/list and RE2 behavior. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Historical/version-scoped behavior must not override a confirmed current implementation. |
| Q24 | [JSON functions reference](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/functions/json_functions_reference.md) | General XQL typed JSON extraction. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Choose the correct return shape and handle invalid/missing paths. |
| Q25 | [Functions list](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/functions/functions-list.md) | General current function inventory. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Global presence is necessary, not sufficient, for restricted contexts. |
| Q26 | [Adding comments in queries](https://cortex-docs.paloaltonetworks.com/cortex-xdr-3.x/cortex-xdr-3.x-documentation/cortex-xdr-xql/get-started-with-xql/xql-language-structure/adding-comments-in-queries.md) | Cortex XDR 3.x `//` and `/* ... */` comments. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Verify the target editor/API/import path; otherwise separate executable code and prose. |
| Q27 | [Parsing Rules file structure and syntax](https://cortex-docs.paloaltonetworks.com/cortex-xsiam/configure-cortex-xsiam/data-management/parsing-rules/parsing-rules-file-structure-and-syntax.md) | Cortex XSIAM XQLp restricted parsing grammar. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Not ordinary Query Center XQL; section, stage, function, join/call, and semicolon rules apply. |
| Q28 | [Create a correlation rule](https://cortex-docs.paloaltonetworks.com/cortex-xsiam/detect-investigate-and-respond-to-threats/threat-management/detection-rules/what-are-detection-rules/whats-a-correlation-rule/create-a-correlation-rule.md) | Cortex XSIAM scheduled/real-time correlation XQL restrictions. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Stage/function/source restrictions, schedule/window, permissions, test results, and hit behavior must be rechecked. |
| Q29 | [Create a BIOC rule](https://cortex-docs.paloaltonetworks.com/cortex-xsiam/detect-investigate-and-respond-to-threats/threat-management/detection-rules/what-are-detection-rules/whats-a-bioc/create-a-bioc-rule.md) | Cortex XSIAM BIOC source, `event_type`, stage/function, test, and safeguard rules. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED` | Interactive validity is not BIOC compatibility; license, historical matches, and false positives remain tenant-dependent. |
| Q30 | [Palo Alto Networks `cortex-xql-queries`](https://github.com/PaloAltoNetworks/cortex-xql-queries/tree/a3a2c0c49e3006a95053a0a4855b043e5d2b5196) | First-party XDR/XSIAM example repository pinned at commit `a3a2c0c49e3006a95053a0a4855b043e5d2b5196`. | `VERSION-DEPENDENT / OFFICIAL-EXAMPLE / TENANT-UNVERIFIED` | Reviewed revision contained the `xql/BruteForceWIndows.md` sample; example fields/logic are not tenant schema, compiler, or detection-quality proof. |

## Supplemental exact-reference pages

| ID | Official source | Used for | Classification and limitation |
|---|---|---|---|
| X01 | [config](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/config.md) | `case_sensitive`, compact timeframe syntax, `between`, first-stage invariant. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; UI picker and rule-context behavior still differ. |
| X02 | [dataset](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/dataset.md) | Single/multiple datasets, `cold_dataset`, source ordering, default `xdr_data`. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; source existence/population unknown. |
| X03 | [sort](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/sort.md) | Ordering, numeric conversion note, sort loss across join/union. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; actual resource use tenant-measured. |
| X04 | [limit](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/limit.md) | Explicit bound and context-specific defaults. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; recheck exact destination. |
| X05 | [lowercase](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/functions/lowercase.md) | String normalization and null return. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; validate restricted contexts. |
| X06 | [last](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/functions/last.md) | Newest aggregate value and null semantics. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; chronology/source clocks still matter. |
| X07 | [count with comp](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/functions/count_with_comp_stage.md) | Row count versus non-null field count. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; aggregation changes schema/cardinality. |
| X08 | [XQL Schema Reference](https://cortex-docs.paloaltonetworks.com/xql-schema-reference/readme.md) | General schema-navigation root. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; documentation is not tenant observation. |
| X09 | [XDR data fields](https://cortex-docs.paloaltonetworks.com/xql-schema-reference/xdr-data-fields.md) | `_time`, `agent_hostname`, `agent_id`, `event_type`. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; population/visibility unknown. |
| X10 | [Action actor fields](https://cortex-docs.paloaltonetworks.com/xql-schema-reference/xdr-data-fields-by-actor/action-actor.md) | Process image, command line, and process username fields. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; OS/event coverage unknown. |
| X11 | [Actor actor fields](https://cortex-docs.paloaltonetworks.com/xql-schema-reference/xdr-data-fields-by-actor/actor-actor.md) | Effective actor username. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; population and identity scope unknown. |
| X12 | [target](https://cortex-docs.paloaltonetworks.com/xql-command-reference-guide/readme/stages/target.md) | Final-stage persistence to dataset/lookup and explicit append/overwrite semantics. | `VERIFIED / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; state-changing, omitted `append` defaults to overwrite, and target ownership/authorization/recovery require tenant evidence. |
| X13 | [Host Inventory](https://cortex-docs.paloaltonetworks.com/cortex-xsiam/protect-your-endpoints/endpoint-security/install-and-manage-endpoints/harden-endpoint-security/host-inventory.md) | Installed endpoint application/software inventory boundary. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; does not establish a Business Application or DLP application definition. |
| X14 | [Business Applications](https://cortex-docs.paloaltonetworks.com/application-security/application-security-posture-management-aspm/applications.md) | Application Security/ASPM logical application boundary. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; do not infer Host Inventory rows or XQL schema. |
| X15 | [Endpoint Applications permission](https://cortex-docs.paloaltonetworks.com/cortex-xsiam/reference-and-developer-docs/role-based-access-control/data-security-endpoint-dlp-permissions/endpoint-applications.md) | Endpoint DLP application-definition permission boundary. | `VERSION-DEPENDENT / OFFICIAL-CURRENT / TENANT-UNVERIFIED`; DLP license, object data, and effective role remain tenant-specific. |

## Revalidation procedure

Before updating a query or release:

1. Re-open the exact product/version pages, not a search-result snippet or generic portal.
2. Check page product labels and final redirect destinations.
3. Compare syntax, types, restrictions, limits, terminology, and license/RBAC notes to this register.
4. Record new review date and material differences.
5. Re-pin living repositories and inspect the exact reused file.
6. Re-run behavioral, ambiguity, adversarial, and regression tests affected by the change.
7. Preserve unresolved conflicts, especially `regextract()`, until target evidence resolves them.
8. Never upgrade tenant claim level from a documentation refresh alone.

The source URLs establish documentation traceability. They do not grant permission to run queries, access tenant data, create rules, or take response actions.
